/**
 * Theme: Rizz - Bootstrap 5 Responsive Admin Dashboard
 * Author: Mannatthemes
 * Editor Js
 */


const quill = new Quill("#editor", {
  theme: "snow",
});